# HW1_simple
The simple version of the first HW assignment.   

See hw1_music.pdf for the description of the assignment.
